/* KoreanBridge MVP – plain JS SPA */

// Router-like navigation between views and drawers
const views = {
  home: document.getElementById('view-home'),
  learning: document.getElementById('view-learning'),
  media: document.getElementById('view-media'),
  community: document.getElementById('view-community'),
  kculture: document.getElementById('view-kculture'),
};

const drawers = {
  rewards: document.getElementById('view-rewards'),
  travel: document.getElementById('view-travel'),
  dictionary: document.getElementById('view-dictionary'),
};

function showView(name) {
  Object.values(views).forEach((el) => el.classList.remove('view-active'));
  const el = name === 'home' ? views.home : views[name];
  if (el) el.classList.add('view-active');
}

function openDrawer(name) {
  Object.values(drawers).forEach((el) => el.classList.remove('open'));
  const el = drawers[name];
  if (el) el.classList.add('open');
}

function closeDrawer() {
  Object.values(drawers).forEach((el) => el.classList.remove('open'));
}

document.querySelectorAll('.js-nav').forEach((el) => {
  el.addEventListener('click', () => {
    const target = el.getAttribute('data-target');
    if (target in views || target === 'home') {
      showView(target === 'home' ? 'home' : target);
      closeDrawer();
    } else if (target in drawers) {
      openDrawer(target);
    }
  });
});

document.querySelectorAll('[data-close]').forEach((btn) =>
  btn.addEventListener('click', closeDrawer)
);

// Seasonal background changes weekly
(function applySeasonalBackground() {
  const week = Math.floor(Date.now() / (1000 * 60 * 60 * 24 * 7));
  const seasons = ['spring', 'summer', 'fall', 'winter'];
  const season = seasons[week % seasons.length];
  document.body.classList.add(`season-${season}`);
})();

// Coins stored in localStorage
const COIN_KEY = 'kb_coins_v1';
function getCoins() {
  return Number(localStorage.getItem(COIN_KEY) || '0');
}
function setCoins(value) {
  const v = Math.max(0, Number(value) || 0);
  localStorage.setItem(COIN_KEY, String(v));
  document.getElementById('coin-badge').textContent = String(v);
}
setCoins(getCoins());

document.getElementById('earn-coin').addEventListener('click', () => {
  setCoins(getCoins() + 1);
});
document.getElementById('spend-coin').addEventListener('click', () => {
  setCoins(getCoins() - 1);
});

// Batchim remover (final consonant stripping)
// Hangul syllable decomposition: U+AC00..U+D7A3
function removeBatchim(text) {
  let result = '';
  for (const ch of text) {
    const code = ch.charCodeAt(0);
    if (code < 0xac00 || code > 0xd7a3) {
      result += ch;
      continue;
    }
    const syllableIndex = code - 0xac00;
    const initialIndex = Math.floor(syllableIndex / (21 * 28));
    const vowelIndex = Math.floor((syllableIndex % (21 * 28)) / 28);
    const base = 0xac00 + (initialIndex * 21 + vowelIndex) * 28; // no final consonant
    result += String.fromCharCode(base);
  }
  return result;
}

document.getElementById('btn-batchim').addEventListener('click', () => {
  const input = /** @type {HTMLTextAreaElement} */ (document.getElementById('batchim-input'));
  const out = document.getElementById('batchim-output');
  out.textContent = removeBatchim(input.value);
});
document.getElementById('btn-copy').addEventListener('click', async () => {
  const out = document.getElementById('batchim-output').textContent || '';
  try {
    await navigator.clipboard.writeText(out);
    alert('Copied');
  } catch (_) {}
});

// Dictionary tool reuse
document.getElementById('dict-run').addEventListener('click', () => {
  const input = /** @type {HTMLInputElement} */ (document.getElementById('dict-input'));
  document.getElementById('dict-output').textContent = removeBatchim(input.value);
});

// Loanword mini game
const loanwords = [
  { ko: '노트북', en: 'laptop' },
  { ko: '핸드폰', en: 'phone' },
  { ko: '아이스크림', en: 'ice cream' },
  { ko: '버스', en: 'bus' },
];
let currentLoan = 0;
function renderLoanword() {
  document.getElementById('loanword').textContent = loanwords[currentLoan].ko;
}
renderLoanword();
document.getElementById('loanword-check').addEventListener('click', () => {
  const guess = /** @type {HTMLInputElement} */ (document.getElementById('loanword-guess')).value.trim().toLowerCase();
  const { en } = loanwords[currentLoan];
  const result = document.getElementById('loanword-result');
  if (!guess) return;
  if (guess === en.toLowerCase()) {
    result.textContent = '✅ Correct!';
    currentLoan = (currentLoan + 1) % loanwords.length;
    renderLoanword();
    setCoins(getCoins() + 1);
  } else {
    result.textContent = `❌ Hint: ${en[0].toUpperCase()}...`;
  }
});

// Media likes/comments demo
let likeCount = 0;
let dislikeCount = 0;
document.getElementById('like').addEventListener('click', () => {
  likeCount += 1; document.getElementById('like-count').textContent = String(likeCount);
});
document.getElementById('dislike').addEventListener('click', () => {
  dislikeCount += 1; document.getElementById('dislike-count').textContent = String(dislikeCount);
});
document.getElementById('comment-add').addEventListener('click', () => {
  const input = /** @type {HTMLInputElement} */ (document.getElementById('comment-input'));
  if (!input.value.trim()) return;
  const li = document.createElement('li');
  li.textContent = input.value.trim();
  document.getElementById('comment-list').appendChild(li);
  input.value = '';
});

// Community friend search (mock)
document.getElementById('friend-btn').addEventListener('click', () => {
  const q = /** @type {HTMLInputElement} */ (document.getElementById('friend-search')).value.trim();
  const ul = document.getElementById('friend-results');
  ul.innerHTML = '';
  if (!q) return;
  const mock = ['haneul', 'seojun', 'minji', 'yuna', 'dohyun']
    .filter((n) => n.includes(q.toLowerCase()));
  mock.forEach((n) => {
    const li = document.createElement('li');
    li.textContent = `@${n}`;
    ul.appendChild(li);
  });
});

// K‑Culture carousel controls
const track = document.getElementById('kculture-track');
document.getElementById('kc-prev').addEventListener('click', () => {
  track.scrollBy({ left: -track.clientWidth, behavior: 'smooth' });
});
document.getElementById('kc-next').addEventListener('click', () => {
  track.scrollBy({ left: track.clientWidth, behavior: 'smooth' });
});

// Simple i18n
const i18n = {
  en: {
    title: 'KoreanBridge',
    language: 'Language',
    ctaStart: 'Start Learning for Free',
    quote: 'A wise man can acquaint himself with Hangeul before the morning is over. A foolish man can learn it in ten days.',
    quoteAuthor: '— King Sejong',
    cardLearning: 'Learning',
    cardMedia: 'Media',
    cardCommunity: 'Community',
    cardKculture: 'K‑Culture',
    learningItem1: 'Consonant‑Free Story',
    learningItem2: 'Loanword Vocabulary Game',
    learningDesc1: 'Type Korean text and remove final consonants (batchim) to practice reading.',
    learningDesc2: 'Guess the English meaning of a Korean loanword.',
    mediaItem1: 'Video Upload',
    mediaItem2: 'Likes & Comments',
    mediaNote: 'This is a demo. Files are not uploaded.',
    communityItem1: 'Find Friends',
    communityItem2: 'SNS Integration',
    snsNote: 'Connect your social accounts (demo only).',
    kcultureItem1: 'Drama',
    kcultureItem2: 'Music',
    kcultureItem3: 'Tradition',
    kcultureItem4: 'Food',
    navRewards: 'Rewards',
    navTravel: 'Travel',
    navDictionary: 'Dictionary',
    rewardsDesc: 'Earn coins as you learn. This demo stores your coins in the browser.',
    btnEarn: 'Earn 1 Coin',
    btnSpend: 'Spend 1 Coin',
    travelHint: 'Find hidden spots in Busan, Geoje, and Gyeongnam!',
    dictTool1: 'Batchim Remover',
    btnConvert: 'Convert',
    btnCopy: 'Copy',
    btnCheck: 'Check',
    btnAdd: 'Add',
    btnSearch: 'Search',
  },
  ko: {
    title: '코리안브릿지',
    language: '언어',
    ctaStart: '무료로 시작하기',
    quote: '어진 이는 아침나절에, 어리석은 이도 열흘이면 한글을 익힐 수 있다.',
    quoteAuthor: '— 세종대왕',
    cardLearning: '학습',
    cardMedia: '미디어',
    cardCommunity: '커뮤니티',
    cardKculture: 'K‑컬처',
    learningItem1: '받침 없는 이야기',
    learningItem2: '외래어 어휘 게임',
    learningDesc1: '한글 문장에서 받침을 제거해 읽기 연습을 합니다.',
    learningDesc2: '한국어 외래어의 영어 뜻을 맞혀보세요.',
    mediaItem1: '영상 업로드',
    mediaItem2: '좋아요·댓글',
    mediaNote: '데모입니다. 실제 업로드는 하지 않습니다.',
    communityItem1: '친구 찾기',
    communityItem2: 'SNS 연동',
    snsNote: '소셜 계정 연동 (데모).',
    kcultureItem1: '드라마',
    kcultureItem2: '음악',
    kcultureItem3: '전통',
    kcultureItem4: '음식',
    navRewards: '리워드',
    navTravel: '여행',
    navDictionary: '사전',
    rewardsDesc: '학습하며 코인을 모으세요. 브라우저에 저장됩니다.',
    btnEarn: '1코인 획득',
    btnSpend: '1코인 사용',
    travelHint: '부산·거제·경남의 숨은 명소를 찾아보세요!',
    dictTool1: '받침 제거기',
    btnConvert: '변환',
    btnCopy: '복사',
    btnCheck: '확인',
    btnAdd: '추가',
    btnSearch: '검색',
  },
  es: {
    title: 'KoreanBridge',
    language: 'Idioma',
    ctaStart: 'Empezar gratis',
    quote: 'Un sabio aprende Hangul en una mañana; un necio en diez días.',
    quoteAuthor: '— Rey Sejong',
    cardLearning: 'Aprendizaje',
    cardMedia: 'Medios',
    cardCommunity: 'Comunidad',
    cardKculture: 'K‑Cultura',
    learningItem1: 'Historia sin consonantes finales',
    learningItem2: 'Juego de préstamos',
    learningDesc1: 'Quita la consonante final para practicar lectura.',
    learningDesc2: 'Adivina el significado en inglés.',
    mediaItem1: 'Subir video',
    mediaItem2: 'Me gusta y comentarios',
    mediaNote: 'Demostración. No se suben archivos.',
    communityItem1: 'Buscar amigos',
    communityItem2: 'Integración SNS',
    snsNote: 'Conecta tus redes (demo).',
    kcultureItem1: 'Drama',
    kcultureItem2: 'Música',
    kcultureItem3: 'Tradición',
    kcultureItem4: 'Comida',
    navRewards: 'Recompensas',
    navTravel: 'Viaje',
    navDictionary: 'Diccionario',
    rewardsDesc: 'Gana monedas mientras aprendes. Se guardan en el navegador.',
    btnEarn: 'Ganar 1 moneda',
    btnSpend: 'Gastar 1 moneda',
    travelHint: '¡Encuentra lugares ocultos en Busan, Geoje y Gyeongnam!',
    dictTool1: 'Removedor de batchim',
    btnConvert: 'Convertir',
    btnCopy: 'Copiar',
    btnCheck: 'Verificar',
    btnAdd: 'Agregar',
    btnSearch: 'Buscar',
  },
};

const langSelect = document.getElementById('lang-select');
function applyLang(lang) {
  const dict = i18n[lang] || i18n.en;
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (key && dict[key]) {
      if ('value' in el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
        el.setAttribute('placeholder', dict[key]);
      } else {
        el.textContent = dict[key];
      }
    }
  });
}
langSelect.addEventListener('change', () => applyLang(langSelect.value));
applyLang(langSelect.value);


